//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : uart.h
// Purpose : Debug UART on header H3 (115200 8N1).
//           GPIO28 = TX (H3.1), GPIO29 = RX (H3.2), H3.3 = GND.
//           Implemented with the LINA module in SCI (UART) mode, which is the
//           peripheral that provides TX on GPIO28 and RX on GPIO29.
//           Reception is interrupt driven into a 64-byte ring buffer.
//#############################################################################
#ifndef UART_H
#define UART_H

#include <stdint.h>

#define UART_BAUD       115200UL

void    UART_init(void);
void    UART_putc(char c);              // blocking
void    UART_puts(const char *s);       // blocking
int16_t UART_getc(void);                // -1 when no character is available

extern volatile uint32_t g_uartRxOverflow;  // ring buffer full, character dropped
extern volatile uint32_t g_uartRxErr;       // overrun / framing errors

#endif // UART_H
