//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : test_pwm.c
// Purpose : Test pulse generator, see test_pwm.h.
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include "test_pwm.h"

// TBCLK = SYSCLK / (CLKDIV 32 * HSPCLKDIV 1) = 3.125 MHz -> 1 us = 3.125 counts
#define TB_HZ               (DEVICE_SYSCLK_FREQ / 32UL)
#define US_TO_CNT(us)       ((uint16_t)(((uint32_t)(us) * (TB_HZ / 1000UL)) / 1000UL))
#define TEST_TBPRD          (US_TO_CNT(TEST_PWM_PERIOD_US) - 1U)   // 62499

volatile uint32_t g_testPulseUsA = TEST_PWM_MIN_US;
volatile uint32_t g_testPulseUsB = TEST_PWM_MIN_US;

static void applyWidth(void)
{
    EPWM_setCounterCompareValue(EPWM1_BASE, EPWM_COUNTER_COMPARE_A,
                                US_TO_CNT(g_testPulseUsA));
    EPWM_setCounterCompareValue(EPWM1_BASE, EPWM_COUNTER_COMPARE_B,
                                US_TO_CNT(g_testPulseUsB));
}

static void computeWidth(uint16_t step)
{
    g_testPulseUsA = TEST_PWM_MIN_US + (uint32_t)step * TEST_PWM_STEP_US;
#if TEST_PWM_B_REVERSE
    g_testPulseUsB = TEST_PWM_MAX_US - (uint32_t)step * TEST_PWM_STEP_US;
#else
    g_testPulseUsB = g_testPulseUsA;
#endif
}

void TestPwm_init(void)
{
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    EPWM_setClockPrescaler(EPWM1_BASE, EPWM_CLOCK_DIVIDER_32, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(EPWM1_BASE, TEST_TBPRD);
    EPWM_setTimeBaseCounter(EPWM1_BASE, 0U);
    EPWM_setTimeBaseCounterMode(EPWM1_BASE, EPWM_COUNTER_MODE_UP);
    EPWM_disablePhaseShiftLoad(EPWM1_BASE);

    EPWM_setCounterCompareShadowLoadMode(EPWM1_BASE, EPWM_COUNTER_COMPARE_A,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareShadowLoadMode(EPWM1_BASE, EPWM_COUNTER_COMPARE_B,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);

    // Output high from CTR = 0 until CMPx
    EPWM_setActionQualifierAction(EPWM1_BASE, EPWM_AQ_OUTPUT_A,
        EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(EPWM1_BASE, EPWM_AQ_OUTPUT_A,
        EPWM_AQ_OUTPUT_LOW,  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(EPWM1_BASE, EPWM_AQ_OUTPUT_B,
        EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(EPWM1_BASE, EPWM_AQ_OUTPUT_B,
        EPWM_AQ_OUTPUT_LOW,  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);

    // No dead band
    EPWM_setDeadBandDelayMode(EPWM1_BASE, EPWM_DB_RED, false);
    EPWM_setDeadBandDelayMode(EPWM1_BASE, EPWM_DB_FED, false);

    computeWidth(0U);
    applyWidth();

    GPIO_setPadConfig(0U, GPIO_PIN_TYPE_STD);
    GPIO_setPadConfig(1U, GPIO_PIN_TYPE_STD);
    GPIO_setPinConfig(GPIO_0_EPWM1_A);      // INHA_A
    GPIO_setPinConfig(GPIO_1_EPWM1_B);      // INLA_A

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
}

void TestPwm_tick1ms(void)
{
    static uint16_t ms   = 0U;
    static uint16_t step = 0U;
    const uint16_t nStep = (uint16_t)((TEST_PWM_MAX_US - TEST_PWM_MIN_US) / TEST_PWM_STEP_US);

    if(++ms >= TEST_PWM_STEP_MS)
    {
        ms = 0U;
        step = (step >= nStep) ? 0U : (uint16_t)(step + 1U);
        computeWidth(step);
        applyWidth();       // shadow registers: takes effect at the next period
    }
}
