//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : uart.c
// Purpose : LINA in SCI mode, 8 data bits, no parity, 1 stop bit.
//
// LIN module clock (VCLK) = SYSCLK = 100 MHz.
// Baud = VCLK / ((P + 1 + M/16) * 16)  ->  N = VCLK / baud = 16 * (P + 1) + M
// 115200 bps: N = 868, P = 53, M = 4 -> 115207 bps (+0.006 %)
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "uart.h"

#define LIN_VCLK_HZ     (DEVICE_SYSCLK_FREQ)
#define LIN_BAUD_N      ((LIN_VCLK_HZ + (UART_BAUD / 2UL)) / UART_BAUD)
#define LIN_BAUD_P      ((LIN_BAUD_N / 16UL) - 1UL)
#define LIN_BAUD_M      (LIN_BAUD_N % 16UL)

//-----------------------------------------------------------------------------
// Receive ring buffer (written by the ISR, read by the main loop)
//-----------------------------------------------------------------------------
#define RX_BUF_SIZE     64U         // power of two

static volatile uint16_t s_rxBuf[RX_BUF_SIZE];
static volatile uint16_t s_rxHead = 0U;
static volatile uint16_t s_rxTail = 0U;

volatile uint32_t g_uartRxOverflow = 0U;
volatile uint32_t g_uartRxErr      = 0U;

__interrupt void uartRxISR(void);

static void rxPush(uint16_t c)
{
    uint16_t next = (s_rxHead + 1U) & (RX_BUF_SIZE - 1U);
    if(next != s_rxTail)
    {
        s_rxBuf[s_rxHead] = c;
        s_rxHead = next;
    }
    else
    {
        g_uartRxOverflow++;
    }
}

int16_t UART_getc(void)
{
    int16_t c;
    if(s_rxTail == s_rxHead)
    {
        return -1;
    }
    c = (int16_t)(s_rxBuf[s_rxTail] & 0xFFU);
    s_rxTail = (s_rxTail + 1U) & (RX_BUF_SIZE - 1U);
    return c;
}

//-----------------------------------------------------------------------------
void UART_init(void)
{
    GPIO_setPinConfig(GPIO_28_LINA_TX);
    GPIO_setPinConfig(GPIO_29_LINA_RX);
    GPIO_setPadConfig(UART_TX_PIN, GPIO_PIN_TYPE_STD);
    GPIO_setPadConfig(UART_RX_PIN, GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(UART_RX_PIN, GPIO_QUAL_ASYNC);

    LIN_initModule(LINA_BASE);

    LIN_enterSoftwareReset(LINA_BASE);
    LIN_enableSCIMode(LINA_BASE);
    LIN_setSCICommMode(LINA_BASE, LIN_COMM_SCI_IDLELINE);
    LIN_setSCIStopBits(LINA_BASE, LIN_SCI_STOP_ONE);
    LIN_disableSCIParity(LINA_BASE);
    LIN_disableMultibufferMode(LINA_BASE);
    LIN_setDebugSuspendMode(LINA_BASE, LIN_DEBUG_COMPLETE);
    LIN_setSCICharLength(LINA_BASE, 8U);
    LIN_setSCIFrameLength(LINA_BASE, 1U);
    LIN_setBaudRatePrescaler(LINA_BASE, LIN_BAUD_P, LIN_BAUD_M);
    LIN_disableIntLoopback(LINA_BASE);

    // Receive interrupt on LIN interrupt line 0
    LIN_enableSCIInterrupt(LINA_BASE, LIN_SCI_INT_RX);
    LIN_setSCIInterruptLevel0(LINA_BASE, LIN_SCI_INT_RX);
    LIN_exitSoftwareReset(LINA_BASE);

    LIN_enableGlobalInterrupt(LINA_BASE, LIN_INTERRUPT_LINE0);
    LIN_clearGlobalInterruptStatus(LINA_BASE, LIN_INTERRUPT_LINE0);

    Interrupt_register(INT_LINA_0, &uartRxISR);
    Interrupt_enable(INT_LINA_0);
}

__interrupt void uartRxISR(void)
{
    uint32_t st = LIN_getInterruptStatus(LINA_BASE);

    if((st & (LIN_INT_OE | LIN_INT_FE)) != 0U)
    {
        g_uartRxErr++;
        LIN_clearInterruptStatus(LINA_BASE, LIN_INT_OE | LIN_INT_FE | LIN_INT_PE);
    }

    while(LIN_isSCIDataAvailable(LINA_BASE))
    {
        rxPush(LIN_readSCICharNonBlocking(LINA_BASE, false));
    }

    LIN_clearInterruptStatus(LINA_BASE, LIN_INT_RX);
    LIN_clearGlobalInterruptStatus(LINA_BASE, LIN_INTERRUPT_LINE0);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP8);
}

void UART_putc(char c)
{
    LIN_writeSCICharBlocking(LINA_BASE, (uint16_t)c & 0xFFU);
}

void UART_puts(const char *s)
{
    while(*s != '\0')
    {
        UART_putc(*s++);
    }
}
