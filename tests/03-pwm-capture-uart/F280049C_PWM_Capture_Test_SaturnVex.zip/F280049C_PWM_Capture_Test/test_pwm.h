//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : test_pwm.h
// Purpose : RC/servo-style test pulse generator on INHA_A (GPIO0, EPWM1A) and
//           INLA_A (GPIO1, EPWM1B), used as a known source for the PWM
//           capture inputs.
//
//  EPWM1 up-count, TBCLK = 100 MHz / 32 = 3.125 MHz (0.32 us per count).
//  Period 20 ms (50 Hz); pulse width steps 1.0 -> 2.0 ms in 0.2 ms steps,
//  one step every 2 s, then repeats.
//
//  WARNING: GPIO0/GPIO1 are the motor A phase-A gate-driver inputs. Both pins
//  are driven high at the same time, so the motor A gate driver must stay
//  disabled (DRV_A_ENABLE = 0, done by the application) or be unplugged.
//#############################################################################
#ifndef TEST_PWM_H
#define TEST_PWM_H

#include <stdint.h>

#define TEST_PWM_PERIOD_US      20000UL
#define TEST_PWM_MIN_US         1000UL
#define TEST_PWM_MAX_US         2000UL
#define TEST_PWM_STEP_US        200UL
#define TEST_PWM_STEP_MS        2000UL

// 0: INLA_A outputs the same width as INHA_A
// 1: INLA_A runs the sequence in reverse (2.0 -> 1.0 ms), which makes the two
//    capture channels easy to tell apart
#define TEST_PWM_B_REVERSE      0

extern volatile uint32_t g_testPulseUsA;   // width currently output on INHA_A (us)
extern volatile uint32_t g_testPulseUsB;   // width currently output on INLA_A (us)

void TestPwm_init(void);
void TestPwm_tick1ms(void);                // call from a 1 ms ISR

#endif // TEST_PWM_H
