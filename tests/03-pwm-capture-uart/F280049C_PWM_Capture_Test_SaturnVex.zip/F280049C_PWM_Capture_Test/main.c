//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// Project : F280049C_PWM_Capture_Test
// File    : main.c
// Purpose : Measures the pulse width, period, frequency and duty cycle of the
//           two PWM command inputs and reports them to a PC over UART.
//
//  Capture : PWM_A_INPUT GPIO40 -> INPUTXBAR7 -> eCAP1
//            PWM_B_INPUT GPIO14 -> INPUTXBAR8 -> eCAP2
//            Continuous mode, 4 events R/F/R/F, counter reset on every event
//            (delta mode): CAP3 = low time, CAP4 = high time. 10 ns resolution.
//  No signal: no edge for PWM_LOST_MS -> valid = 0 and the duty is reported
//            as 0 % or 100 % according to the static pin level.
//
//  Test source (test_pwm.c): INHA_A GPIO0 / INLA_A GPIO1, 50 Hz,
//            1.0 -> 2.0 ms in 0.2 ms steps every 2 s.
//            Loop-back wiring: GPIO0 (U12.2) -> H2.2 (PWM_A), GPIO1 (U12.4) -> H2.1 (PWM_B).
//
//  UART (H3) : 115200 8N1. One line every REPORT_MS, for example:
//            OUT=1200/1200us | A: H=1200.00us T=20000.00us F=50.00Hz D=6.00% | B: ...
//
//  PC commands (end with CR/LF, or pause for CMD_IDLE_MS; case-insensitive,
//  spaces ignored):
//            STOP  -> replies "OK STOP", then stops the periodic report
//            START -> replies "OK START", then resumes the periodic report
//            other -> replies "ERR UNKNOWN CMD: ..."
//
//  CCS Expressions: g_pwmA, g_pwmB, g_testPulseUsA/B, g_reportEnable,
//                   g_cmdLast, g_cmdOkCnt, g_cmdErrCnt, g_uartLineCnt,
//                   g_uartRxCnt, g_uartLastRx, g_uartRxErr, g_uartRxOverflow
//  LED_Status blinks at 1 Hz.
//#############################################################################
#include <stdint.h>
#include <stdbool.h>
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "uart.h"
#include "test_pwm.h"

#define REPORT_MS           100U
#define PWM_LOST_MS         200UL       // lowest measurable input ~ 1000/200 = 5 Hz
#define PWM_LOST_TICKS      (PWM_LOST_MS * (DEVICE_SYSCLK_FREQ / 1000UL))
#define TICK_HZ             1000UL
#define ECAP_ALL_INT_SRC    (ECAP_ISR_SOURCE_CAPTURE_EVENT_1  | \
                             ECAP_ISR_SOURCE_CAPTURE_EVENT_2  | \
                             ECAP_ISR_SOURCE_CAPTURE_EVENT_3  | \
                             ECAP_ISR_SOURCE_CAPTURE_EVENT_4  | \
                             ECAP_ISR_SOURCE_COUNTER_OVERFLOW | \
                             ECAP_ISR_SOURCE_COUNTER_PERIOD   | \
                             ECAP_ISR_SOURCE_COUNTER_COMPARE)
#define CMD_MAX_LEN         16U
#define CMD_IDLE_MS         50UL        // command without CR/LF runs after 50 ms idle

typedef struct
{
    uint32_t highCnt;       // high time in 10 ns counts
    uint32_t lowCnt;        // low time in 10 ns counts
    uint32_t periodCnt;     // period in 10 ns counts
    float    highUs;        // pulse width (us)
    float    lowUs;
    float    periodUs;
    float    freqHz;
    float    dutyPct;
    uint16_t valid;         // 1 = signal present
    uint16_t level;         // static pin level while no signal is present
    uint32_t captureCnt;    // number of updates (one every two periods)
} PwmIn_t;

volatile PwmIn_t  g_pwmA;
volatile PwmIn_t  g_pwmB;
volatile uint32_t g_uartLineCnt  = 0U;
volatile uint32_t g_uartRxCnt    = 0U;
volatile int16_t  g_uartLastRx   = -1;
volatile uint16_t g_reportFlag   = 0U;
volatile uint32_t g_msTick       = 0U;

volatile uint16_t g_reportEnable = 1U;  // 1 = periodic report on (default at start-up)
char              g_cmdLast[CMD_MAX_LEN];
volatile uint32_t g_cmdOkCnt     = 0U;
volatile uint32_t g_cmdErrCnt    = 0U;

__interrupt void ecap1ISR(void);
__interrupt void ecap2ISR(void);
__interrupt void cpuTimer0ISR(void);

//-----------------------------------------------------------------------------
// Initialisation
//-----------------------------------------------------------------------------
static void ledInit(void)
{
    GPIO_setPinConfig(GPIO_59_GPIO59);
    GPIO_setPadConfig(LED_STATUS_PIN, GPIO_PIN_TYPE_STD);
    GPIO_writePin(LED_STATUS_PIN, 0U);
    GPIO_setDirectionMode(LED_STATUS_PIN, GPIO_DIR_MODE_OUT);

    // Gate drivers held disabled
    GPIO_setPinConfig(GPIO_34_GPIO34);
    GPIO_setPinConfig(GPIO_30_GPIO30);
    GPIO_writePin(DRV_A_ENABLE_PIN, 0U);
    GPIO_writePin(DRV_B_ENABLE_PIN, 0U);
    GPIO_setDirectionMode(DRV_A_ENABLE_PIN, GPIO_DIR_MODE_OUT);
    GPIO_setDirectionMode(DRV_B_ENABLE_PIN, GPIO_DIR_MODE_OUT);
}

static void pwmInPinInit(uint32_t pin, uint32_t pinCfg, XBAR_InputNum xbarIn)
{
    GPIO_setPinConfig(pinCfg);
    GPIO_setDirectionMode(pin, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(pin, GPIO_PIN_TYPE_PULLUP);       // open input reads high
    GPIO_setQualificationMode(pin, GPIO_QUAL_3SAMPLE);  // rejects glitches < ~40 ns
    GPIO_setQualificationPeriod(pin, 2U);
    XBAR_setInputPin(xbarIn, (uint16_t)pin);
}

static void ecapInit(uint32_t base, ECAP_InputCaptureSignals input)
{
    ECAP_disableInterrupt(base, ECAP_ALL_INT_SRC);
    ECAP_clearInterrupt(base, ECAP_ALL_INT_SRC);
    ECAP_clearGlobalInterrupt(base);

    ECAP_disableTimeStampCapture(base);
    ECAP_stopCounter(base);
    ECAP_enableCaptureMode(base);

    ECAP_setCaptureMode(base, ECAP_CONTINUOUS_CAPTURE_MODE, ECAP_EVENT_4);
    ECAP_setEventPrescaler(base, 0U);

    ECAP_setEventPolarity(base, ECAP_EVENT_1, ECAP_EVNT_RISING_EDGE);
    ECAP_setEventPolarity(base, ECAP_EVENT_2, ECAP_EVNT_FALLING_EDGE);
    ECAP_setEventPolarity(base, ECAP_EVENT_3, ECAP_EVNT_RISING_EDGE);
    ECAP_setEventPolarity(base, ECAP_EVENT_4, ECAP_EVNT_FALLING_EDGE);

    ECAP_enableCounterResetOnEvent(base, ECAP_EVENT_1);
    ECAP_enableCounterResetOnEvent(base, ECAP_EVENT_2);
    ECAP_enableCounterResetOnEvent(base, ECAP_EVENT_3);
    ECAP_enableCounterResetOnEvent(base, ECAP_EVENT_4);

    ECAP_selectECAPInput(base, input);
    ECAP_disableLoadCounter(base);
    ECAP_setSyncOutMode(base, ECAP_SYNC_OUT_DISABLED);

    ECAP_resetCounters(base);
    ECAP_startCounter(base);
    ECAP_enableTimeStampCapture(base);
    ECAP_reArm(base);

    ECAP_enableInterrupt(base, ECAP_ISR_SOURCE_CAPTURE_EVENT_4);
}

static void captureInit(void)
{
    pwmInPinInit(PWM_A_IN_PIN, GPIO_40_GPIO40, XBAR_INPUT7);
    pwmInPinInit(PWM_B_IN_PIN, GPIO_14_GPIO14, XBAR_INPUT8);

    ecapInit(ECAP1_BASE, ECAP_INPUT_INPUTXBAR7);
    ecapInit(ECAP2_BASE, ECAP_INPUT_INPUTXBAR8);

    Interrupt_register(INT_ECAP1, &ecap1ISR);
    Interrupt_register(INT_ECAP2, &ecap2ISR);
    Interrupt_enable(INT_ECAP1);
    Interrupt_enable(INT_ECAP2);
}

static void tickTimerInit(void)
{
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_setPeriod(CPUTIMER0_BASE, (DEVICE_SYSCLK_FREQ / TICK_HZ) - 1UL);
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0U);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_setEmulationMode(CPUTIMER0_BASE,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);
    Interrupt_enable(INT_TIMER0);
    CPUTimer_startTimer(CPUTIMER0_BASE);
}

//-----------------------------------------------------------------------------
// Measurement and formatting
//-----------------------------------------------------------------------------
static void pwmUpdate(volatile PwmIn_t *p, uint32_t low, uint32_t high)
{
    uint32_t per = low + high;

    p->lowCnt    = low;
    p->highCnt   = high;
    p->periodCnt = per;
    p->lowUs     = (float)low  * 0.01f;
    p->highUs    = (float)high * 0.01f;
    p->periodUs  = (float)per  * 0.01f;
    p->freqHz    = (per != 0U) ? ((float)DEVICE_SYSCLK_FREQ / (float)per) : 0.0f;
    p->dutyPct   = (per != 0U) ? ((float)high * 100.0f / (float)per) : 0.0f;
    p->valid     = 1U;
    p->captureCnt++;
}

static void pwmCheckLost(uint32_t ecapBase, uint32_t pin, volatile PwmIn_t *p)
{
    // The eCAP counter is reset on every edge, so its value is the time
    // since the last edge.
    if(ECAP_getTimeBaseCounter(ecapBase) > PWM_LOST_TICKS)
    {
        uint16_t lvl = (uint16_t)GPIO_readPin(pin);

        p->valid     = 0U;
        p->level     = lvl;
        p->highCnt   = 0U;
        p->lowCnt    = 0U;
        p->periodCnt = 0U;
        p->highUs    = 0.0f;
        p->lowUs     = 0.0f;
        p->periodUs  = 0.0f;
        p->freqHz    = 0.0f;
        p->dutyPct   = (lvl != 0U) ? 100.0f : 0.0f;
    }
}

static char *putU32(char *d, uint32_t v)
{
    char tmp[10];
    uint16_t n = 0U;

    do
    {
        tmp[n++] = (char)('0' + (v % 10UL));
        v /= 10UL;
    } while(v != 0UL);

    while(n > 0U)
    {
        *d++ = tmp[--n];
    }
    return d;
}

// Print a value scaled by 100 as "123.45"
static char *putFix2(char *d, uint64_t x100)
{
    uint32_t frac = (uint32_t)(x100 % 100ULL);

    d = putU32(d, (uint32_t)(x100 / 100ULL));
    *d++ = '.';
    *d++ = (char)('0' + (frac / 10U));
    *d++ = (char)('0' + (frac % 10U));
    return d;
}

static char *putStr(char *d, const char *s)
{
    while(*s != '\0') { *d++ = *s++; }
    return d;
}

static char *formatChannel(char *d, char name, const PwmIn_t *p)
{
    *d++ = name;
    d = putStr(d, ": ");

    if(p->valid == 0U)
    {
        d = putStr(d, (p->level != 0U) ? "NO SIGNAL (HIGH, D=100.00%)"
                                        : "NO SIGNAL (LOW, D=0.00%)");
        return d;
    }

    // Integer arithmetic only: 1 count = 10 ns = 0.01 us, so us x 100 = count
    d = putStr(d, "H=");  d = putFix2(d, p->highCnt);   d = putStr(d, "us T=");
    d = putFix2(d, p->periodCnt);                        d = putStr(d, "us F=");
    d = putFix2(d, (10000000000ULL + (p->periodCnt / 2U)) / p->periodCnt);
    d = putStr(d, "Hz D=");
    d = putFix2(d, ((uint64_t)p->highCnt * 10000ULL + (p->periodCnt / 2U)) / p->periodCnt);
    *d++ = '%';
    return d;
}

static void sendReport(void)
{
    static char line[160];
    PwmIn_t a, b;
    uint32_t outA, outB;
    uint16_t st;
    char *d = line;

    // Consistent snapshot of the values updated by the ISRs
    st = __disable_interrupts();
    a = *(const PwmIn_t *)&g_pwmA;
    b = *(const PwmIn_t *)&g_pwmB;
    outA = g_testPulseUsA;
    outB = g_testPulseUsB;
    __restore_interrupts(st);

    // Width currently generated by the test source, for comparison
    d = putStr(d, "OUT=");
    d = putU32(d, outA);
    *d++ = '/';
    d = putU32(d, outB);
    d = putStr(d, "us | ");

    d = formatChannel(d, 'A', &a);
    d = putStr(d, " | ");
    d = formatChannel(d, 'B', &b);
    d = putStr(d, "\r\n");
    *d = '\0';

    UART_puts(line);
    g_uartLineCnt++;
}

//-----------------------------------------------------------------------------
// UART command interpreter
//-----------------------------------------------------------------------------
static char     s_cmdBuf[CMD_MAX_LEN];
static uint16_t s_cmdLen      = 0U;
static bool     s_cmdTooLong  = false;
static uint32_t s_cmdLastRxMs = 0U;

static bool strEq(const char *a, const char *b)
{
    while((*a != '\0') && (*a == *b)) { a++; b++; }
    return (*a == *b);
}

static void cmdExecute(void)
{
    uint16_t i;

    s_cmdBuf[s_cmdLen] = '\0';
    for(i = 0U; i <= s_cmdLen; i++) { g_cmdLast[i] = s_cmdBuf[i]; }

    if(s_cmdTooLong)
    {
        UART_puts("ERR CMD TOO LONG\r\n");
        g_cmdErrCnt++;
    }
    else if(strEq(s_cmdBuf, "STOP"))
    {
        UART_puts("OK STOP - report disabled\r\n");    // acknowledge first,
        g_reportEnable = 0U;                            // then stop reporting
        g_cmdOkCnt++;
    }
    else if(strEq(s_cmdBuf, "START"))
    {
        UART_puts("OK START - report enabled\r\n");
        g_reportFlag   = 0U;                            // first line at the next period
        g_reportEnable = 1U;
        g_cmdOkCnt++;
    }
    else
    {
        UART_puts("ERR UNKNOWN CMD: ");
        UART_puts(s_cmdBuf);
        UART_puts(" (use START / STOP)\r\n");
        g_cmdErrCnt++;
    }

    s_cmdLen     = 0U;
    s_cmdTooLong = false;
}

static void cmdRxChar(int16_t c)
{
    s_cmdLastRxMs = g_msTick;

    if((c == '\r') || (c == '\n'))
    {
        if((s_cmdLen > 0U) || s_cmdTooLong) { cmdExecute(); }
    }
    else if((c == 0x08) || (c == 0x7F))         // backspace
    {
        if(s_cmdLen > 0U) { s_cmdLen--; }
    }
    else if((c <= 0x20) || (c > 0x7E))
    {
        // ignore spaces and control characters
    }
    else if(s_cmdLen < (CMD_MAX_LEN - 1U))
    {
        if((c >= 'a') && (c <= 'z')) { c = (int16_t)(c - 'a' + 'A'); }
        s_cmdBuf[s_cmdLen++] = (char)c;
    }
    else
    {
        s_cmdTooLong = true;
    }
}

static void cmdPoll(void)
{
    int16_t c;

    while((c = UART_getc()) >= 0)
    {
        g_uartLastRx = c;
        g_uartRxCnt++;
        cmdRxChar(c);
    }

    // Terminals that send without CR/LF: execute after an idle gap
    if(((s_cmdLen > 0U) || s_cmdTooLong) &&
       ((g_msTick - s_cmdLastRxMs) >= CMD_IDLE_MS))
    {
        cmdExecute();
    }
}

//-----------------------------------------------------------------------------
void main(void)
{
    Device_init();
    Device_initGPIO();

    Interrupt_initModule();
    Interrupt_initVectorTable();

    ledInit();
    UART_init();
    captureInit();
    TestPwm_init();
    tickTimerInit();

    EINT;
    ERTM;

    UART_puts("\r\nF280049C PWM capture test - PWM_A=GPIO40, PWM_B=GPIO14\r\n");
    UART_puts("Commands: START / STOP\r\n");

    for(;;)
    {
        cmdPoll();

        if(g_reportFlag != 0U)
        {
            g_reportFlag = 0U;
            if(g_reportEnable != 0U)
            {
                sendReport();
            }
        }
    }
}

//-----------------------------------------------------------------------------
// Interrupt service routines
//-----------------------------------------------------------------------------
__interrupt void ecap1ISR(void)
{
    pwmUpdate(&g_pwmA, ECAP_getEventTimeStamp(ECAP1_BASE, ECAP_EVENT_3),
                       ECAP_getEventTimeStamp(ECAP1_BASE, ECAP_EVENT_4));
    ECAP_clearInterrupt(ECAP1_BASE, ECAP_ISR_SOURCE_CAPTURE_EVENT_4);
    ECAP_clearGlobalInterrupt(ECAP1_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP4);
}

__interrupt void ecap2ISR(void)
{
    pwmUpdate(&g_pwmB, ECAP_getEventTimeStamp(ECAP2_BASE, ECAP_EVENT_3),
                       ECAP_getEventTimeStamp(ECAP2_BASE, ECAP_EVENT_4));
    ECAP_clearInterrupt(ECAP2_BASE, ECAP_ISR_SOURCE_CAPTURE_EVENT_4);
    ECAP_clearGlobalInterrupt(ECAP2_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP4);
}

__interrupt void cpuTimer0ISR(void)     // 1 ms
{
    static uint16_t ledCnt = 0U;
    static uint16_t repCnt = 0U;

    g_msTick++;

    TestPwm_tick1ms();

    pwmCheckLost(ECAP1_BASE, PWM_A_IN_PIN, &g_pwmA);
    pwmCheckLost(ECAP2_BASE, PWM_B_IN_PIN, &g_pwmB);

    if(++repCnt >= REPORT_MS)
    {
        repCnt = 0U;
        g_reportFlag = 1U;
    }

    if(++ledCnt >= 500U)
    {
        ledCnt = 0U;
        GPIO_togglePin(LED_STATUS_PIN);
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
