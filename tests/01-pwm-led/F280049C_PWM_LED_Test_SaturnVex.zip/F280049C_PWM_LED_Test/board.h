//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : board.h
// Purpose : Pin map of the SaturnVex SVX-MCU-F49C-001 dual-motor control
//           board (U5 = TMS320F280049C, 100-pin LQFP). Shared by all test
//           projects.
//
// Schematic net labels start with the MCU port: "IOn_<function>" is GPIOn,
// "ADCINxn_<function>" is ADC input xn. Each line below lists
//   net label | LQFP pin | board connector pin
// so the pins can be located by either the schematic name or the MCU port.
// Power-board connectors (2 x 7, 1.27 mm, bottom side):
//   U11 motor A analog, U12 motor A digital, U4 motor B analog,
//   U6 motor B digital.
//#############################################################################
#ifndef BOARD_H
#define BOARD_H

#include "driverlib.h"
#include "device.h"

//-----------------------------------------------------------------------------
// Status / user LEDs (active high)
//-----------------------------------------------------------------------------
#define LED_STATUS_PIN      59U     // IO59_LED_Status   pin 92  on-board LED U8
#define LED1_PIN            23U     // IO23_SW_LED1      pin 81  U11.4
#define LED2_PIN            25U     // IO25_LED2         pin 57  U4.4

//-----------------------------------------------------------------------------
// Gate driver - motor A (connector U12)
//   IO0_INHA_A  GPIO0 EPWM1A pin 79 U12.2  | IO1_INLA_A GPIO1 EPWM1B pin 78 U12.4
//   IO2_INHB_A  GPIO2 EPWM2A pin 77 U12.6  | IO3_INLB_A GPIO3 EPWM2B pin 76 U12.8
//   IO4_INHC_A  GPIO4 EPWM3A pin 75 U12.10 | IO5_INLC_A GPIO5 EPWM3B pin 89 U12.12
//-----------------------------------------------------------------------------
#define DRV_A_MODE_PIN      12U     // IO12_DRV_A_MODE   pin 51  U12.1
#define DRV_A_ENABLE_PIN    34U     // IO34_DRV_A_ENABLE pin 94  U12.11
#define DRV_A_NFAULT_PIN    27U     // IO27_DRV_A_nFAULT pin 59  U11.6
#define DRV_A_CAL_PIN       13U     // IO13_DRV_A_CAL    pin 50  U11.12

//-----------------------------------------------------------------------------
// Gate driver - motor B (connector U6)
//   IO8_INHA_B  GPIO8  EPWM5A pin 74 U6.2  | IO7_INLA_B  GPIO7  EPWM4B pin 84 U6.4
//   IO9_INHB_B  GPIO9  EPWM5B pin 90 U6.6  | IO6_INLB_B  GPIO6  EPWM4A pin 97 U6.8
//   IO10_INHC_B GPIO10 EPWM6A pin 93 U6.10 | IO11_INLC_B GPIO11 EPWM6B pin 52 U6.12
//   Phases A and B have INH and INL on different ePWM modules (see pwm.c).
//-----------------------------------------------------------------------------
#define DRV_B_MODE_PIN      15U     // IO15_DRV_B_MODE   pin 95  U6.1
#define DRV_B_ENABLE_PIN    30U     // IO30_DRV_B_ENABLE pin 98  U6.11
#define DRV_B_NFAULT_PIN    39U     // IO39_DRV_B_nFAULT pin 91  U4.6
#define DRV_B_CAL_PIN       58U     // IO58_DRV_B_CAL    pin 67  U4.12

//-----------------------------------------------------------------------------
// PWM command inputs (header H2, H2.5 / H2.6 = GND)
//-----------------------------------------------------------------------------
#define PWM_A_IN_PIN        40U     // IO40_PWM_A_INPUT  pin 85  H2.2
#define PWM_B_IN_PIN        14U     // IO14_PWM_B_INPUT  pin 96  H2.1

//-----------------------------------------------------------------------------
// Debug UART (header H3, H3.3 = GND) - LINA module in SCI mode
//-----------------------------------------------------------------------------
#define UART_TX_PIN         28U     // IO28_UART_TX      pin 1   H3.1 (LINA_TX)
#define UART_RX_PIN         29U     // IO29_UART_RX      pin 100 H3.2 (LINA_RX)

//-----------------------------------------------------------------------------
// CAN (transceiver U7 SN65HVD234, connector CN1: 3 = CAN_H, 2 = CAN_L, 1 = GND)
//-----------------------------------------------------------------------------
#define CAN_TX_PIN          32U     // IO32_BOOT1_CANTX  pin 64  U7.D (CANA_TX)
#define CAN_RX_PIN          33U     // IO33_CANRX        pin 53  U7.R (CANA_RX)

//-----------------------------------------------------------------------------
// Gate-driver SPI on U12 / U6 (not used by the test firmware)
//-----------------------------------------------------------------------------
#define SPIA_SIMO_PIN       16U     // IO16_SPIA_MOSI    pin 54  U12.5
#define SPIA_SOMI_PIN       17U     // IO17_SPIA_MISO    pin 55  U12.3
#define SPIA_CLK_PIN        56U     // IO56_SPIA_CLK     pin 65  U12.9
#define SPIA_STE_PIN        57U     // IO57_SPIA_CS      pin 66  U12.7 (10k pull-up R10)
#define SPIB_SIMO_PIN       24U     // IO24_BOOT0_SPIB_MOSI pin 56 U6.5 (boot pin)
#define SPIB_SOMI_PIN       31U     // IO31_SPIB_MISO    pin 99  U6.3
#define SPIB_CLK_PIN        22U     // IO22_SW_SPIB_CLK  pin 83  U6.9
#define SPIB_CS_PIN         26U     // IO26_SPIB_CS      pin 58  U6.7 (10k pull-up R9)
                                    // GPIO26 has no SPIB_STE function: drive it
                                    // as a GPIO chip select (SPIB master only).

#endif // BOARD_H
