//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : pwm.c
// Purpose : 45 kHz center-aligned PWM for two three-phase bridges.
//
// Gate-drive pin assignment of the SVX-MCU-F49C-001 board:
//   Motor A phase A : INH GPIO0  EPWM1A | INL GPIO1  EPWM1B
//   Motor A phase B : INH GPIO2  EPWM2A | INL GPIO3  EPWM2B
//   Motor A phase C : INH GPIO4  EPWM3A | INL GPIO5  EPWM3B
//   Motor B phase A : INH GPIO8  EPWM5A | INL GPIO7  EPWM4B
//   Motor B phase B : INH GPIO9  EPWM5B | INL GPIO6  EPWM4A
//   Motor B phase C : INH GPIO10 EPWM6A | INL GPIO11 EPWM6B
//
// Dead time:
//   EPWM1/2/3/6 - one module per phase, the dead-band unit generates the
//                 complementary low side (Active High Complementary).
//   EPWM4/5     - motor B phases A and B have high and low side on different
//                 modules, so the dead-band unit cannot be used. EPWM5 drives
//                 both high sides, EPWM4 both low sides, and the dead time is
//                 made by the compare values:
//                   high side on while CTR > cmp + DB/2
//                   low side  on while CTR < cmp - DB/2
//                 In up-down mode this gives exactly DB counts of dead time
//                 at both edges, the same as the dead-band unit.
//
// Convention : cmp = PRD * (1 - d); the high side is on while CTR > cmp.
// Sync chain : EPWM1 SYNCOUT at CTR = 0 -> EPWM2/3/4, EPWM4 passes it to 5/6.
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include "pwm.h"

#define DB_HALF     (PWM_DEADBAND_CNT / 2U)

// Duty limits keep a minimum pulse width of about one dead time and keep the
// split compare values (cmp +/- DB_HALF) inside 1 .. TBPRD - 1.
#define CMP_MIN     (DB_HALF + 1U)
#define CMP_MAX     (PWM_TBPRD - DB_HALF - 1U)

static const uint32_t s_allBase[6] =
{
    EPWM1_BASE, EPWM2_BASE, EPWM3_BASE, EPWM4_BASE, EPWM5_BASE, EPWM6_BASE
};

// Last compare values of motor B phases A and B (split-module phases)
static uint16_t s_cmpBA = PWM_TBPRD / 2U;
static uint16_t s_cmpBB = PWM_TBPRD / 2U;

//-----------------------------------------------------------------------------
// Time base: up-down count, prescaler 1, EPWM1 is the sync master
//-----------------------------------------------------------------------------
static void pwmTimeBaseInit(uint32_t base, bool master)
{
    EPWM_setClockPrescaler(base, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(base, PWM_TBPRD);
    EPWM_setPeriodLoadMode(base, EPWM_PERIOD_SHADOW_LOAD);
    EPWM_setTimeBaseCounter(base, 0U);
    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_UP_DOWN);
    EPWM_setPhaseShift(base, 0U);

    if(master)
    {
        EPWM_disablePhaseShiftLoad(base);
        EPWM_setSyncOutPulseMode(base, EPWM_SYNC_OUT_PULSE_ON_COUNTER_ZERO);
    }
    else
    {
        EPWM_enablePhaseShiftLoad(base);
        EPWM_setCountModeAfterSync(base, EPWM_COUNT_MODE_UP_AFTER_SYNC);
        EPWM_setSyncOutPulseMode(base, EPWM_SYNC_OUT_PULSE_ON_EPWMxSYNCIN);
    }

    // Compare registers are written directly during init and switched to
    // shadow mode at the end of PWM_init().
    EPWM_disableCounterCompareShadowLoadMode(base, EPWM_COUNTER_COMPARE_A);
    EPWM_disableCounterCompareShadowLoadMode(base, EPWM_COUNTER_COMPARE_B);
    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_A, PWM_TBPRD / 2U);
    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_B, PWM_TBPRD / 2U);

    // Trip-zone action: force both outputs low if a trip is ever configured
    EPWM_setTripZoneAction(base, EPWM_TZ_ACTION_EVENT_TZA, EPWM_TZ_ACTION_LOW);
    EPWM_setTripZoneAction(base, EPWM_TZ_ACTION_EVENT_TZB, EPWM_TZ_ACTION_LOW);
}

//-----------------------------------------------------------------------------
// One module per phase: A = INH, B = INL, hardware dead band (AHC)
//-----------------------------------------------------------------------------
static void pwmHalfBridgeHwDb(uint32_t base)
{
    // EPWMxA high while CTR > CMPA
    EPWM_setActionQualifierAction(base, EPWM_AQ_OUTPUT_A,
        EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(base, EPWM_AQ_OUTPUT_A,
        EPWM_AQ_OUTPUT_LOW,  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);

    // Active High Complementary, both delays sourced from EPWMxA
    EPWM_setRisingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);
    EPWM_setFallingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_RED, EPWM_DB_POLARITY_ACTIVE_HIGH);
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
    EPWM_setDeadBandDelayMode(base, EPWM_DB_RED, true);
    EPWM_setDeadBandDelayMode(base, EPWM_DB_FED, true);
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_A, false);
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_B, false);
    EPWM_setDeadBandCounterClock(base, EPWM_DB_COUNTER_CLOCK_FULL_CYCLE);
    EPWM_setRisingEdgeDelayCount(base, PWM_DEADBAND_CNT);
    EPWM_setFallingEdgeDelayCount(base, PWM_DEADBAND_CNT);
}

//-----------------------------------------------------------------------------
// Split-module outputs (EPWM4 / EPWM5): dead band unit bypassed, every output
// driven directly by the action qualifier.
//   highSide = true : output high while CTR > compare (INH)
//   highSide = false: output high while CTR < compare (INL)
// The zero / period actions fix the level at the counter turning points, so
// the outputs are defined from the first period on.
//-----------------------------------------------------------------------------
static void pwmSplitOutput(uint32_t base, EPWM_ActionQualifierOutputModule out,
                           bool highSide)
{
    bool isA = (out == EPWM_AQ_OUTPUT_A);
    EPWM_ActionQualifierOutputEvent up   = isA ? EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA
                                               : EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB;
    EPWM_ActionQualifierOutputEvent down = isA ? EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA
                                               : EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB;
    EPWM_ActionQualifierOutput on  = EPWM_AQ_OUTPUT_HIGH;
    EPWM_ActionQualifierOutput off = EPWM_AQ_OUTPUT_LOW;

    EPWM_setActionQualifierAction(base, out, highSide ? on : off, up);
    EPWM_setActionQualifierAction(base, out, highSide ? off : on, down);
    EPWM_setActionQualifierAction(base, out, highSide ? off : on,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(base, out, highSide ? on : off,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
}

static void pwmSplitModuleInit(uint32_t base, bool highSide)
{
    EPWM_setDeadBandDelayMode(base, EPWM_DB_RED, false);
    EPWM_setDeadBandDelayMode(base, EPWM_DB_FED, false);
    pwmSplitOutput(base, EPWM_AQ_OUTPUT_A, highSide);
    pwmSplitOutput(base, EPWM_AQ_OUTPUT_B, highSide);
}

//-----------------------------------------------------------------------------
static uint16_t dutyToCmp(float d)
{
    float c = (float)PWM_TBPRD * (1.0f - d);
    if(c < (float)CMP_MIN) { c = (float)CMP_MIN; }
    if(c > (float)CMP_MAX) { c = (float)CMP_MAX; }
    return (uint16_t)c;
}

//-----------------------------------------------------------------------------
// Update one split-module phase. hiBase/hiCmp is the INH compare, loBase/loCmp
// the INL compare. The side whose pulse gets shorter is written first: if a
// CTR = 0 shadow load falls between the two writes, the phase runs one period
// with a longer dead time, never with an overlap.
//-----------------------------------------------------------------------------
static void pwmSetSplitPhase(uint32_t hiBase, EPWM_CounterCompareModule hiCmp,
                             uint32_t loBase, EPWM_CounterCompareModule loCmp,
                             uint16_t cmp, uint16_t *last)
{
    uint16_t hi = cmp + DB_HALF;
    uint16_t lo = cmp - DB_HALF;

    if(cmp >= *last)
    {
        // Duty falls: high-side pulse shrinks first
        EPWM_setCounterCompareValue(hiBase, hiCmp, hi);
        EPWM_setCounterCompareValue(loBase, loCmp, lo);
    }
    else
    {
        // Duty rises: low-side pulse shrinks first
        EPWM_setCounterCompareValue(loBase, loCmp, lo);
        EPWM_setCounterCompareValue(hiBase, hiCmp, hi);
    }
    *last = cmp;
}

//-----------------------------------------------------------------------------
void PWM_setDuty(PWM_Motor motor, float da, float db, float dc)
{
    uint16_t ca = dutyToCmp(da);
    uint16_t cb = dutyToCmp(db);
    uint16_t cc = dutyToCmp(dc);

    if(motor == MOTOR_A)
    {
        EPWM_setCounterCompareValue(EPWM1_BASE, EPWM_COUNTER_COMPARE_A, ca);
        EPWM_setCounterCompareValue(EPWM2_BASE, EPWM_COUNTER_COMPARE_A, cb);
        EPWM_setCounterCompareValue(EPWM3_BASE, EPWM_COUNTER_COMPARE_A, cc);
    }
    else
    {
        // Phase A: INH = EPWM5A (CMPA), INL = EPWM4B (CMPB)
        pwmSetSplitPhase(EPWM5_BASE, EPWM_COUNTER_COMPARE_A,
                         EPWM4_BASE, EPWM_COUNTER_COMPARE_B, ca, &s_cmpBA);
        // Phase B: INH = EPWM5B (CMPB), INL = EPWM4A (CMPA)
        pwmSetSplitPhase(EPWM5_BASE, EPWM_COUNTER_COMPARE_B,
                         EPWM4_BASE, EPWM_COUNTER_COMPARE_A, cb, &s_cmpBB);
        // Phase C: one module, hardware dead band
        EPWM_setCounterCompareValue(EPWM6_BASE, EPWM_COUNTER_COMPARE_A, cc);
    }
}

//-----------------------------------------------------------------------------
static void pwmGpioInit(void)
{
    static const uint32_t pinCfg[12] =
    {
        GPIO_0_EPWM1_A,  GPIO_1_EPWM1_B,    // GPIO0 INHA_A  / GPIO1 INLA_A
        GPIO_2_EPWM2_A,  GPIO_3_EPWM2_B,    // GPIO2 INHB_A  / GPIO3 INLB_A
        GPIO_4_EPWM3_A,  GPIO_5_EPWM3_B,    // GPIO4 INHC_A  / GPIO5 INLC_A
        GPIO_6_EPWM4_A,  GPIO_7_EPWM4_B,    // GPIO6 INLB_B  / GPIO7 INLA_B
        GPIO_8_EPWM5_A,  GPIO_9_EPWM5_B,    // GPIO8 INHA_B  / GPIO9 INHB_B
        GPIO_10_EPWM6_A, GPIO_11_EPWM6_B    // GPIO10 INHC_B / GPIO11 INLC_B
    };
    uint16_t i;

    for(i = 0U; i < 12U; i++)
    {
        GPIO_setPadConfig(i, GPIO_PIN_TYPE_STD);
        GPIO_setPinConfig(pinCfg[i]);
    }
}

//-----------------------------------------------------------------------------
void PWM_init(void)
{
    uint16_t i;

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    // EPWM4 SYNCIN = EPWM1 SYNCOUT
    SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);

    for(i = 0U; i < 6U; i++)
    {
        pwmTimeBaseInit(s_allBase[i], (i == 0U));
    }

    pwmHalfBridgeHwDb(EPWM1_BASE);
    pwmHalfBridgeHwDb(EPWM2_BASE);
    pwmHalfBridgeHwDb(EPWM3_BASE);
    pwmSplitModuleInit(EPWM4_BASE, false);      // low sides of motor B A / B
    pwmSplitModuleInit(EPWM5_BASE, true);       // high sides of motor B A / B
    pwmHalfBridgeHwDb(EPWM6_BASE);

    // s_cmpBA / s_cmpBB start at TBPRD / 2, so the first call writes the
    // split compare values in a safe order.
    PWM_setDuty(MOTOR_A, 0.5f, 0.5f, 0.5f);
    PWM_setDuty(MOTOR_B, 0.5f, 0.5f, 0.5f);

    // From here on CMPA/CMPB use shadow registers loaded at CTR = 0, so duty
    // updates from a control ISR take effect at a period boundary.
    for(i = 0U; i < 6U; i++)
    {
        EPWM_setCounterCompareShadowLoadMode(s_allBase[i], EPWM_COUNTER_COMPARE_A,
                                             EPWM_COMP_LOAD_ON_CNTR_ZERO);
        EPWM_setCounterCompareShadowLoadMode(s_allBase[i], EPWM_COUNTER_COMPARE_B,
                                             EPWM_COMP_LOAD_ON_CNTR_ZERO);
    }

    pwmGpioInit();

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
}
