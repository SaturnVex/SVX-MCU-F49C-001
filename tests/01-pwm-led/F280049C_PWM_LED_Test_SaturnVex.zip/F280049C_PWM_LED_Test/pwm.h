//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// File    : pwm.h
// Purpose : Six ePWM modules driving the INH/INL inputs of two three-phase
//           gate drivers (motor A and motor B), 45 kHz center-aligned PWM.
//#############################################################################
#ifndef PWM_H
#define PWM_H

#include <stdint.h>

#define PWM_FREQ_HZ         45000UL

// Up-down count: Fpwm = TBCLK / (2 * TBPRD), TBCLK = SYSCLK = 100 MHz
// TBPRD = 100 MHz / (2 * 45 kHz) = 1111 -> 45.004 kHz
#define PWM_TBPRD           ((uint16_t)(DEVICE_SYSCLK_FREQ / (2UL * PWM_FREQ_HZ)))

// Dead time in TBCLK counts (10 ns each): 50 counts = 500 ns.
#define PWM_DEADBAND_CNT    50U

typedef enum
{
    MOTOR_A = 0,
    MOTOR_B = 1
} PWM_Motor;

// Configure all six ePWM modules, dead time (hardware dead band on EPWM1/2/3/6,
// compare-based on the split EPWM4/5 phases), synchronisation and pin mux.
// All phases start at 50 % duty.
void PWM_init(void);

// Set the high-side duty cycle (0.0 .. 1.0) of the three phases of a motor.
// The duty is the high-side on-time ratio before dead time is applied.
// The high side conducts around CTR = PRD and the low side around CTR = 0,
// which is the usual instant for low-side shunt current sampling.
void PWM_setDuty(PWM_Motor motor, float da, float db, float dc);

#endif // PWM_H
