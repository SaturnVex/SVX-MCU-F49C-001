//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// Project : F280049C_PWM_LED_Test
// File    : main.c
// Purpose : LED toggle test and 45 kHz gate-drive PWM test for the SaturnVex
//           F280049C dual-motor (2 x PMSM, sensorless FOC) control board.
//
//  - LED1 (GPIO23) and LED2 (GPIO25) toggle every 1 ms -> 500 Hz square wave.
//    At this frequency the LEDs look half-bright; verify with a scope.
//  - LED_Status (GPIO59) blinks at 1 Hz (toggles every 500 ms).
//  - All 12 INH/INL gate-drive outputs of motor A and motor B run at 45 kHz,
//    center-aligned, 500 ns dead time.
//  - Driver nFAULT inputs are monitored in g_drvAFault / g_drvBFault.
//
// Clock: SYSCLK = 100 MHz from the 20 MHz crystal (device.h defaults).
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "pwm.h"

//-----------------------------------------------------------------------------
// Gate driver enable
//   0 : drivers stay disabled (ENABLE = 0). Only the INH/INL logic signals are
//       measured. Each phase uses a different duty (25 / 50 / 75 %) so the
//       pins are easy to identify on a scope.
//   1 : drivers are enabled with 50 % duty on all three phases (zero
//       line-to-line voltage). Do not use unequal duties with the drivers
//       enabled and a motor connected.
//-----------------------------------------------------------------------------
#define DRV_GATE_ENABLE     0

#define TICK_HZ             1000UL                                  // 1 ms tick
#define LED_TIMER_PERIOD    (DEVICE_SYSCLK_FREQ / TICK_HZ)
#define LED_STATUS_HZ       1UL
#define LED_STATUS_TOGGLE_TICKS ((uint16_t)(TICK_HZ / (2UL * LED_STATUS_HZ)))

volatile uint32_t g_ledTick    = 0U;   // 1 ms tick counter
volatile uint16_t g_drvAFault  = 0U;   // 1 = motor A driver nFAULT active (low)
volatile uint16_t g_drvBFault  = 0U;   // 1 = motor B driver nFAULT active (low)

__interrupt void cpuTimer0ISR(void);

//-----------------------------------------------------------------------------
static void ledInit(void)
{
    // GPIO23 shares its pin with the DC-DC switch node: select digital mode
    GPIO_setAnalogMode(LED1_PIN, GPIO_ANALOG_DISABLED);

    GPIO_setPinConfig(GPIO_59_GPIO59);
    GPIO_setPinConfig(GPIO_23_GPIO23);
    GPIO_setPinConfig(GPIO_25_GPIO25);

    GPIO_setPadConfig(LED_STATUS_PIN, GPIO_PIN_TYPE_STD);
    GPIO_setPadConfig(LED1_PIN,       GPIO_PIN_TYPE_STD);
    GPIO_setPadConfig(LED2_PIN,       GPIO_PIN_TYPE_STD);

    GPIO_writePin(LED_STATUS_PIN, 0U);
    GPIO_writePin(LED1_PIN,       0U);
    GPIO_writePin(LED2_PIN,       0U);

    GPIO_setDirectionMode(LED_STATUS_PIN, GPIO_DIR_MODE_OUT);
    GPIO_setDirectionMode(LED1_PIN,       GPIO_DIR_MODE_OUT);
    GPIO_setDirectionMode(LED2_PIN,       GPIO_DIR_MODE_OUT);
}

static void drvInit(void)
{
    static const uint32_t outPins[6] =
    {
        DRV_A_MODE_PIN, DRV_A_CAL_PIN, DRV_A_ENABLE_PIN,
        DRV_B_MODE_PIN, DRV_B_CAL_PIN, DRV_B_ENABLE_PIN
    };
    uint16_t i;

    // MODE, CAL and ENABLE outputs, all low (drivers disabled during PWM init)
    GPIO_setPinConfig(GPIO_12_GPIO12);   // DRV_A_MODE
    GPIO_setPinConfig(GPIO_13_GPIO13);   // DRV_A_CAL
    GPIO_setPinConfig(GPIO_34_GPIO34);   // DRV_A_ENABLE
    GPIO_setPinConfig(GPIO_15_GPIO15);   // DRV_B_MODE
    GPIO_setPinConfig(GPIO_58_GPIO58);   // DRV_B_CAL
    GPIO_setPinConfig(GPIO_30_GPIO30);   // DRV_B_ENABLE

    for(i = 0U; i < 6U; i++)
    {
        GPIO_writePin(outPins[i], 0U);
        GPIO_setPadConfig(outPins[i], GPIO_PIN_TYPE_STD);
        GPIO_setDirectionMode(outPins[i], GPIO_DIR_MODE_OUT);
    }

    // nFAULT inputs: open-drain, active low, internal pull-up enabled
    GPIO_setPinConfig(GPIO_27_GPIO27);
    GPIO_setPinConfig(GPIO_39_GPIO39);
    GPIO_setPadConfig(DRV_A_NFAULT_PIN, GPIO_PIN_TYPE_PULLUP);
    GPIO_setPadConfig(DRV_B_NFAULT_PIN, GPIO_PIN_TYPE_PULLUP);
    GPIO_setDirectionMode(DRV_A_NFAULT_PIN, GPIO_DIR_MODE_IN);
    GPIO_setDirectionMode(DRV_B_NFAULT_PIN, GPIO_DIR_MODE_IN);
    GPIO_setQualificationMode(DRV_A_NFAULT_PIN, GPIO_QUAL_3SAMPLE);
    GPIO_setQualificationMode(DRV_B_NFAULT_PIN, GPIO_QUAL_3SAMPLE);
}

static void ledTimerInit(void)
{
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);

    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_setPeriod(CPUTIMER0_BASE, LED_TIMER_PERIOD - 1UL);
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0U);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_setEmulationMode(CPUTIMER0_BASE,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);

    Interrupt_enable(INT_TIMER0);
    CPUTimer_startTimer(CPUTIMER0_BASE);
}

//-----------------------------------------------------------------------------
void main(void)
{
    Device_init();          // 100 MHz clock, peripheral clocks, flash setup
    Device_initGPIO();

    Interrupt_initModule();
    Interrupt_initVectorTable();

    ledInit();
    drvInit();
    PWM_init();

#if DRV_GATE_ENABLE
    PWM_setDuty(MOTOR_A, 0.50f, 0.50f, 0.50f);
    PWM_setDuty(MOTOR_B, 0.50f, 0.50f, 0.50f);
    DEVICE_DELAY_US(1000U);
    GPIO_writePin(DRV_A_ENABLE_PIN, 1U);
    GPIO_writePin(DRV_B_ENABLE_PIN, 1U);
#else
    PWM_setDuty(MOTOR_A, 0.25f, 0.50f, 0.75f);
    PWM_setDuty(MOTOR_B, 0.25f, 0.50f, 0.75f);
#endif

    ledTimerInit();

    EINT;
    ERTM;

    for(;;)
    {
        g_drvAFault = (GPIO_readPin(DRV_A_NFAULT_PIN) == 0U) ? 1U : 0U;
        g_drvBFault = (GPIO_readPin(DRV_B_NFAULT_PIN) == 0U) ? 1U : 0U;
    }
}

//-----------------------------------------------------------------------------
// CPU Timer0, 1 ms
//-----------------------------------------------------------------------------
__interrupt void cpuTimer0ISR(void)
{
    static uint16_t statusCnt = 0U;

    g_ledTick++;

    // LED_Status: 1 Hz blink
    if(++statusCnt >= LED_STATUS_TOGGLE_TICKS)
    {
        statusCnt = 0U;
        GPIO_togglePin(LED_STATUS_PIN);
    }

    // LED1 / LED2: toggle every 1 ms -> 500 Hz
    GPIO_togglePin(LED1_PIN);
    GPIO_togglePin(LED2_PIN);

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
