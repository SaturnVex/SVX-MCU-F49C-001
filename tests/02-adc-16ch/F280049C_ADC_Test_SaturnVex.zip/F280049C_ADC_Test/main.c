//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// Project : F280049C_ADC_Test
// File    : main.c
// Purpose : Measures all 16 analog inputs of the SaturnVex F280049C
//           dual-motor control board (phase currents, phase voltages, DC bus
//           voltages and power-stage temperatures of motor A and motor B).
//
//  - Reference : internal, 3.3 V range (input range 0 .. 3.3 V, 12-bit).
//                In this mode the VREFHI pin is an output (about 1.65 V);
//                header U3 must not be driven externally.
//  - Trigger   : CPU Timer1 at 1 kHz starts all SOCs on ADCA, ADCB and ADCC.
//  - ISR       : ADCA INT1 (end of the last ADCA conversion) reads all results.
//  - CCS Expressions:
//      g_adc.ch.<name>  filtered voltage of each channel (V)
//      g_adcRaw[]       latest 12-bit code
//      g_adcMin/Max[]   min / max code since reset (noise check);
//                       write g_adcStatReset = 1 to restart the statistics
//      g_adcIsrCnt      increments 1000 times per second
//  - LED_Status blinks at 1 Hz from the ADC ISR (ADC running indicator).
//
// SYSCLK 100 MHz, ADCCLK 50 MHz, sample window 100 SYSCLK = 1 us.
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include "board.h"

#define ADC_TRIG_HZ         1000UL
#define ADC_SH_CYCLES       100U            // sample window in SYSCLK cycles (10 ns)
#define ADC_VREF            3.3f
#define ADC_FULL_SCALE      4096.0f
#define ADC_FILTER_K        0.0625f         // first-order IIR, 1/16 (~16 ms)

#define LED_STATUS_TOGGLE_TICKS  ((uint16_t)(ADC_TRIG_HZ / 2UL))   // 1 Hz

//-----------------------------------------------------------------------------
// Channel list - order matches the fields of AdcVolt_t
//-----------------------------------------------------------------------------
#define ADC_NUM_CH          16U

typedef struct
{
    float Ia_A;     // ADCINA6_ISENSE_A_Ia   pin 6   U11.3
    float Ib_A;     // ADCINB2_ISENSE_A_Ib   pin 7   U11.5
    float Ic_A;     // ADCINC0_ISENSE_A_Ic   pin 19  U11.7
    float Vbus_A;   // ADCINA3_VBUS_SENSE_A  pin 10  U11.9
    float Va_A;     // ADCINA2_VPHASE_A_Va   pin 9   U11.11
    float Vb_A;     // ADCINB3_VPHASE_A_Vb   pin 8   U11.13
    float Vc_A;     // ADCINC2_VPHASE_A_Vc   pin 21  U11.14
    float Temp_A;   // ADCINC4_ESC_A_Temp    pin 17  H1.2  (10k pull-up R6)
    float Ia_B;     // ADCINA9_ISENSE_B_Ia   pin 38  U4.3
    float Ib_B;     // ADCINB0_ISENSE_B_Ib   pin 41  U4.5
    float Ic_B;     // ADCINC14_ISENSE_B_Ic  pin 44  U4.7
    float Vbus_B;   // ADCINA4_VBUS_SENSE_B  pin 36  U4.9
    float Va_B;     // ADCINA8_VPHASE_B_Va   pin 37  U4.11
    float Vb_B;     // ADCINB1_VPHASE_B_Vb   pin 40  U4.13
    float Vc_B;     // ADCINC1_VPHASE_B_Vc   pin 29  U4.14
    float Temp_B;   // ADCINA5_ESC_B_Temp    pin 35  H1.4  (10k pull-up R4)
} AdcVolt_t;

typedef union
{
    AdcVolt_t ch;                   // access by name
    float     v[ADC_NUM_CH];        // access by index
} AdcVolt_u;

typedef struct
{
    uint32_t       adcBase;
    uint32_t       resBase;
    ADC_SOCNumber  soc;
    ADC_Channel    channel;
} AdcChCfg_t;

// SOCs are numbered consecutively per ADC: ADCA SOC0..6, ADCB SOC0..3, ADCC SOC0..4
static const AdcChCfg_t s_ch[ADC_NUM_CH] =
{
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER0, ADC_CH_ADCIN6  },  // Ia_A
    { ADCB_BASE, ADCBRESULT_BASE, ADC_SOC_NUMBER0, ADC_CH_ADCIN2  },  // Ib_A
    { ADCC_BASE, ADCCRESULT_BASE, ADC_SOC_NUMBER0, ADC_CH_ADCIN0  },  // Ic_A
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER1, ADC_CH_ADCIN3  },  // Vbus_A
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER2, ADC_CH_ADCIN2  },  // Va_A
    { ADCB_BASE, ADCBRESULT_BASE, ADC_SOC_NUMBER1, ADC_CH_ADCIN3  },  // Vb_A
    { ADCC_BASE, ADCCRESULT_BASE, ADC_SOC_NUMBER1, ADC_CH_ADCIN2  },  // Vc_A
    { ADCC_BASE, ADCCRESULT_BASE, ADC_SOC_NUMBER2, ADC_CH_ADCIN4  },  // Temp_A
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER3, ADC_CH_ADCIN9  },  // Ia_B
    { ADCB_BASE, ADCBRESULT_BASE, ADC_SOC_NUMBER2, ADC_CH_ADCIN0  },  // Ib_B
    { ADCC_BASE, ADCCRESULT_BASE, ADC_SOC_NUMBER3, ADC_CH_ADCIN14 },  // Ic_B
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER4, ADC_CH_ADCIN4  },  // Vbus_B
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER5, ADC_CH_ADCIN8  },  // Va_B
    { ADCB_BASE, ADCBRESULT_BASE, ADC_SOC_NUMBER3, ADC_CH_ADCIN1  },  // Vb_B
    { ADCC_BASE, ADCCRESULT_BASE, ADC_SOC_NUMBER4, ADC_CH_ADCIN1  },  // Vc_B
    { ADCA_BASE, ADCARESULT_BASE, ADC_SOC_NUMBER6, ADC_CH_ADCIN5  },  // Temp_B
};

// Last SOC of each ADC drives its INT1 flag
#define ADCA_LAST_SOC   ADC_SOC_NUMBER6
#define ADCB_LAST_SOC   ADC_SOC_NUMBER3
#define ADCC_LAST_SOC   ADC_SOC_NUMBER4

//-----------------------------------------------------------------------------
// Watch variables
//-----------------------------------------------------------------------------
volatile AdcVolt_u g_adc;
volatile uint16_t  g_adcRaw[ADC_NUM_CH];
volatile uint16_t  g_adcMin[ADC_NUM_CH];
volatile uint16_t  g_adcMax[ADC_NUM_CH];
volatile uint16_t  g_adcStatReset   = 1U;
volatile uint32_t  g_adcIsrCnt      = 0U;
volatile uint32_t  g_adcTimeoutCnt  = 0U;  // ADCB/ADCC not finished when ADCA finished
volatile uint32_t  g_adcOverflowCnt = 0U;  // ADC interrupt overflow events

__interrupt void adcA1ISR(void);

//-----------------------------------------------------------------------------
static void gpioInit(void)
{
    // LED_Status
    GPIO_setPinConfig(GPIO_59_GPIO59);
    GPIO_setPadConfig(LED_STATUS_PIN, GPIO_PIN_TYPE_STD);
    GPIO_writePin(LED_STATUS_PIN, 0U);
    GPIO_setDirectionMode(LED_STATUS_PIN, GPIO_DIR_MODE_OUT);

    // Gate drivers held disabled
    GPIO_setPinConfig(GPIO_34_GPIO34);
    GPIO_setPinConfig(GPIO_30_GPIO30);
    GPIO_writePin(DRV_A_ENABLE_PIN, 0U);
    GPIO_writePin(DRV_B_ENABLE_PIN, 0U);
    GPIO_setDirectionMode(DRV_A_ENABLE_PIN, GPIO_DIR_MODE_OUT);
    GPIO_setDirectionMode(DRV_B_ENABLE_PIN, GPIO_DIR_MODE_OUT);
}

static void adcModuleInit(uint32_t base, ADC_SOCNumber lastSoc)
{
    // Internal reference, 0 .. 3.3 V range (also loads the factory trims)
    ADC_setVREF(base, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V);
    ADC_setPrescaler(base, ADC_CLK_DIV_2_0);                // ADCCLK 50 MHz
    ADC_setInterruptPulseMode(base, ADC_PULSE_END_OF_CONV);
    ADC_enableConverter(base);

    ADC_setInterruptSource(base, ADC_INT_NUMBER1, (uint16_t)lastSoc);
    ADC_disableContinuousMode(base, ADC_INT_NUMBER1);
    ADC_enableInterrupt(base, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(base, ADC_INT_NUMBER1);
}

static void adcInit(void)
{
    uint16_t i;

    adcModuleInit(ADCA_BASE, ADCA_LAST_SOC);
    adcModuleInit(ADCB_BASE, ADCB_LAST_SOC);
    adcModuleInit(ADCC_BASE, ADCC_LAST_SOC);
    DEVICE_DELAY_US(1000U);                                 // ADC power-up time

    for(i = 0U; i < ADC_NUM_CH; i++)
    {
        ADC_setupSOC(s_ch[i].adcBase, s_ch[i].soc, ADC_TRIGGER_CPU1_TINT1,
                     s_ch[i].channel, ADC_SH_CYCLES);
    }

    // Only ADCA INT1 goes to the CPU; ADCB/ADCC INT1 are polled as status flags
    Interrupt_register(INT_ADCA1, &adcA1ISR);
    Interrupt_enable(INT_ADCA1);
}

static void trigTimerInit(void)
{
    CPUTimer_stopTimer(CPUTIMER1_BASE);
    CPUTimer_setPeriod(CPUTIMER1_BASE, (DEVICE_SYSCLK_FREQ / ADC_TRIG_HZ) - 1UL);
    CPUTimer_setPreScaler(CPUTIMER1_BASE, 0U);
    CPUTimer_reloadTimerCounter(CPUTIMER1_BASE);
    CPUTimer_setEmulationMode(CPUTIMER1_BASE,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER1_BASE);   // TINT1 = ADC trigger (CPU INT13 not used)
    CPUTimer_startTimer(CPUTIMER1_BASE);
}

//-----------------------------------------------------------------------------
void main(void)
{
    Device_init();
    Device_initGPIO();

    Interrupt_initModule();
    Interrupt_initVectorTable();

    gpioInit();
    adcInit();
    trigTimerInit();

    EINT;
    ERTM;

    for(;;)
    {
    }
}

//-----------------------------------------------------------------------------
static bool waitAdcDone(uint32_t base)
{
    uint16_t to = 200U;
    while(!ADC_getInterruptStatus(base, ADC_INT_NUMBER1))
    {
        if(--to == 0U) { return false; }
    }
    return true;
}

__interrupt void adcA1ISR(void)
{
    static uint16_t ledCnt = 0U;
    uint16_t i;
    bool rst = (g_adcStatReset != 0U);

    // ADCA has the most SOCs (7) and normally finishes last; ADCB/ADCC are
    // still checked to guarantee consistent results.
    if(!waitAdcDone(ADCB_BASE) || !waitAdcDone(ADCC_BASE))
    {
        g_adcTimeoutCnt++;
    }

    for(i = 0U; i < ADC_NUM_CH; i++)
    {
        uint16_t raw = ADC_readResult(s_ch[i].resBase, s_ch[i].soc);
        float    v   = (float)raw * (ADC_VREF / ADC_FULL_SCALE);

        g_adcRaw[i] = raw;

        if(rst)
        {
            g_adc.v[i]  = v;
            g_adcMin[i] = raw;
            g_adcMax[i] = raw;
        }
        else
        {
            g_adc.v[i] += ADC_FILTER_K * (v - g_adc.v[i]);
            if(raw < g_adcMin[i]) { g_adcMin[i] = raw; }
            if(raw > g_adcMax[i]) { g_adcMax[i] = raw; }
        }
    }
    if(rst) { g_adcStatReset = 0U; }

    if(ADC_getInterruptOverflowStatus(ADCA_BASE, ADC_INT_NUMBER1) ||
       ADC_getInterruptOverflowStatus(ADCB_BASE, ADC_INT_NUMBER1) ||
       ADC_getInterruptOverflowStatus(ADCC_BASE, ADC_INT_NUMBER1))
    {
        g_adcOverflowCnt++;
        ADC_clearInterruptOverflowStatus(ADCA_BASE, ADC_INT_NUMBER1);
        ADC_clearInterruptOverflowStatus(ADCB_BASE, ADC_INT_NUMBER1);
        ADC_clearInterruptOverflowStatus(ADCC_BASE, ADC_INT_NUMBER1);
    }

    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCB_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCC_BASE, ADC_INT_NUMBER1);

    g_adcIsrCnt++;
    if(++ledCnt >= LED_STATUS_TOGGLE_TICKS)
    {
        ledCnt = 0U;
        GPIO_togglePin(LED_STATUS_PIN);
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
