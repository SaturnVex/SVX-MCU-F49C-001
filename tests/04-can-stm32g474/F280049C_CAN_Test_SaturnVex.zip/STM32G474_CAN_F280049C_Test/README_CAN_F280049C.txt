STM32G474 <-> TI F280049C classic CAN 2.0 two-way test (partner project: F280049C_CAN_Test)

F280049C DCAN supports classic CAN only -> FDCAN runs FDCAN_FRAME_CLASSIC (no FD, no BRS, 8 bytes).
500 kbps nominal, FDCAN clock 85 MHz (PCLK1), prescaler 10, seg1 13, seg2 3, SJW 3 -> SP 82.4 %.
APP_CAN_PORT in main.c: 1 = FDCAN1 PB9 TX / PB8 RX (STBY PB7), 2 = FDCAN2 PB13 TX / PB12 RX (STBY PB11). STBY held LOW.

STM32 TX ID 0x123, F280049C TX ID 0x321, both every 1 s, 8 bytes: byte[i] = (seq + i) & 0xFF.
Receiver checks ID / std / classic / DLC 8 / ramp and byte[0] continuity (SEQ JUMP = lost frame).
One-shot TX: each frame reported "ACK OK" or "FAIL <LEC>" (FAIL ACK = no node acknowledged).
PC13 BUTTON: reset counters. UART2 115200 8N1 (ST-Link VCP).

Wiring: CANH-CANH, CANL-CANL, GND-GND. Exactly two 120R terminations on the bus (one at each end).
F280049C board: CN1 pin3 CAN_H, pin2 CAN_L, pin1 GND; 120R via JP4.

.ioc still describes the old FD configuration: do NOT "Generate Code" without updating the IOC
(FrameFormat Classic, NominalSyncJumpWidth 3), or the classic-mode changes in MX_FDCANx_Init are lost.
