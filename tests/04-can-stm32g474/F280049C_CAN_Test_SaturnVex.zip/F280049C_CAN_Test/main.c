//#############################################################################
// SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
// Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
// SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
//
// Project : F280049C_CAN_Test
// File    : main.c
// Purpose : Two-way classic CAN 2.0 test between the SaturnVex F280049C board
//           and the SaturnVex STM32G474 board
//           (partner project: STM32G474_CAN_F280049C_Test).
//
//  CANA : GPIO32 TX / GPIO33 RX -> U7 SN65HVD234 -> CN1 (3 = CAN_H, 2 = CAN_L, 1 = GND)
//  Bus  : CAN 2.0A, 500 kbps. CAN clock = SYSCLK 100 MHz, BRP 10, 20 TQ,
//         TSEG1 15 / TSEG2 4 -> sample point 80 %, SJW 4.
//         (STM32 side: 85 MHz, 10 x 17 tq, sample point 82.4 %, SJW 3)
//  TX   : ID 0x321 every CAN_TX_PERIOD_MS, 8 bytes: byte[i] = (seq + i) & 0xFF.
//         Single-shot transmission (automatic retransmission disabled): each
//         frame is reported "ACK OK" or "FAIL <error>" ("FAIL ACK" means no
//         node acknowledged the frame).
//  RX   : ID 0x123 from the STM32 board. The byte ramp is checked and byte[0]
//         must increase by exactly 1 from frame to frame (SEQ JUMP = lost frame).
//
//  UART (H3, 115200 8N1) commands:
//         START / STOP : enable / disable the log (CAN keeps running)
//         RESET        : clear all counters
//  CCS Expressions: g_can (counters, last TX/RX data, TEC/REC, bus state)
//  LED_Status blinks at 1 Hz.
//#############################################################################
#include <stdint.h>
#include <stdbool.h>
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "uart.h"

#define CAN_BITRATE_BPS     500000UL
#define CAN_TX_ID           0x321U
#define CAN_RX_ID           0x123U
#define CAN_TX_OBJ          1U
#define CAN_RX_OBJ          2U
#define CAN_DLC             8U
#define CAN_TX_PERIOD_MS    1000U
#define CAN_TX_WAIT_US      2000U       // one 8-byte frame at 500 kbps ~ 260 us

#define CMD_MAX_LEN         16U
#define CMD_IDLE_MS         50UL

typedef struct
{
    uint32_t txSeq;
    uint32_t txOk;          // frames transmitted and acknowledged
    uint32_t txFail;        // single-shot transmissions that failed
    uint16_t txLastLec;     // CAN last error code of the last failed frame
    uint32_t rxOk;
    uint32_t rxBad;         // wrong byte ramp
    uint32_t rxSeqJump;     // byte[0] did not increase by 1 (lost frame)
    uint32_t busOffCnt;
    uint16_t txData[CAN_DLC];
    uint16_t rxData[CAN_DLC];
    uint32_t tec;           // transmit error counter
    uint32_t rec;           // receive error counter
    uint32_t status;        // last CAN_ES value
    uint16_t errPassive;
    uint16_t busOff;
} CanTest_t;

volatile CanTest_t g_can;
volatile uint16_t  g_logEnable  = 1U;
volatile uint16_t  g_txFlag     = 0U;
volatile uint32_t  g_msTick     = 0U;
volatile uint32_t  g_uartRxCnt  = 0U;
char               g_cmdLast[CMD_MAX_LEN];

static bool     s_rxHavePrev  = false;
static uint16_t s_rxPrevFirst = 0U;

__interrupt void cpuTimer0ISR(void);

//-----------------------------------------------------------------------------
// Text output helpers
//-----------------------------------------------------------------------------
static char s_line[200];

static char *putStr(char *d, const char *s)
{
    while(*s != '\0') { *d++ = *s++; }
    return d;
}

static char *putU32(char *d, uint32_t v)
{
    char tmp[10];
    uint16_t n = 0U;
    do { tmp[n++] = (char)('0' + (v % 10UL)); v /= 10UL; } while(v != 0UL);
    while(n > 0U) { *d++ = tmp[--n]; }
    return d;
}

static char *putHex(char *d, uint32_t v, uint16_t digits)
{
    static const char hex[] = "0123456789ABCDEF";
    while(digits > 0U)
    {
        digits--;
        *d++ = hex[(v >> (4U * digits)) & 0xFU];
    }
    return d;
}

static void logLine(char *end)
{
    *end++ = '\r'; *end++ = '\n'; *end = '\0';
    if(g_logEnable != 0U) { UART_puts(s_line); }
}

static void logPayload(const char *label, const volatile uint16_t *data)
{
    char *d = putStr(s_line, label);
    uint16_t i;
    for(i = 0U; i < CAN_DLC; i++)
    {
        *d++ = ' ';
        d = putHex(d, data[i] & 0xFFU, 2U);
    }
    logLine(d);
}

static const char *lecName(uint16_t lec)
{
    static const char *const names[8] =
        { "NONE", "STUFF", "FORM", "ACK", "BIT1", "BIT0", "CRC", "NOCHANGE" };
    return names[lec & 7U];
}

//-----------------------------------------------------------------------------
// Initialisation
//-----------------------------------------------------------------------------
static void boardInit(void)
{
    GPIO_setPinConfig(GPIO_59_GPIO59);
    GPIO_setPadConfig(LED_STATUS_PIN, GPIO_PIN_TYPE_STD);
    GPIO_writePin(LED_STATUS_PIN, 0U);
    GPIO_setDirectionMode(LED_STATUS_PIN, GPIO_DIR_MODE_OUT);

    // Gate drivers held disabled
    GPIO_setPinConfig(GPIO_34_GPIO34);
    GPIO_setPinConfig(GPIO_30_GPIO30);
    GPIO_writePin(DRV_A_ENABLE_PIN, 0U);
    GPIO_writePin(DRV_B_ENABLE_PIN, 0U);
    GPIO_setDirectionMode(DRV_A_ENABLE_PIN, GPIO_DIR_MODE_OUT);
    GPIO_setDirectionMode(DRV_B_ENABLE_PIN, GPIO_DIR_MODE_OUT);
}

static void canInit(void)
{
    GPIO_setPinConfig(GPIO_32_CANA_TX);
    GPIO_setPinConfig(GPIO_33_CANA_RX);
    GPIO_setPadConfig(CAN_RX_PIN, GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(CAN_RX_PIN, GPIO_QUAL_ASYNC);

    CAN_initModule(CANA_BASE);
    CAN_selectClockSource(CANA_BASE, CAN_CLOCK_SOURCE_SYS);

    // 100 MHz / 10 = 10 MHz TQ clock, 1 + 15 + 4 = 20 TQ -> 500 kbps, SP 80 %.
    // CAN_setBitTiming() takes register values (actual value - 1).
    CAN_setBitTiming(CANA_BASE,
                     (uint16_t)((DEVICE_SYSCLK_FREQ / (CAN_BITRATE_BPS * 20UL)) - 1U), // BRP 10
                     0U,        // BRPE
                     14U,       // TSEG1 = 15 TQ
                     3U,        // TSEG2 = 4 TQ
                     3U);       // SJW   = 4 TQ

    CAN_disableRetry(CANA_BASE);            // single-shot, same as the STM32 side
    CAN_enableAutoBusOn(CANA_BASE);
    CAN_setAutoBusOnTime(CANA_BASE, DEVICE_SYSCLK_FREQ / 100UL);   // ~10 ms

    // TX object with TxIE: its interrupt-pending flag is set only after a
    // frame has been transmitted and acknowledged. The CPU interrupt itself
    // is not enabled; the flag is polled.
    CAN_setupMessageObject(CANA_BASE, CAN_TX_OBJ, CAN_TX_ID, CAN_MSG_FRAME_STD,
                           CAN_MSG_OBJ_TYPE_TX, 0U, CAN_MSG_OBJ_TX_INT_ENABLE,
                           CAN_DLC);
    CAN_setupMessageObject(CANA_BASE, CAN_RX_OBJ, CAN_RX_ID, CAN_MSG_FRAME_STD,
                           CAN_MSG_OBJ_TYPE_RX, 0x7FFU, CAN_MSG_OBJ_USE_ID_FILTER,
                           CAN_DLC);

    CAN_startModule(CANA_BASE);
}

static void tickTimerInit(void)
{
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_setPeriod(CPUTIMER0_BASE, (DEVICE_SYSCLK_FREQ / 1000UL) - 1UL);
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0U);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_setEmulationMode(CPUTIMER0_BASE,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);
    Interrupt_enable(INT_TIMER0);
    CPUTimer_startTimer(CPUTIMER0_BASE);
}

//-----------------------------------------------------------------------------
// CAN test
//-----------------------------------------------------------------------------
static void canResetCounters(void)
{
    g_can.txSeq = 0U;  g_can.txOk = 0U;  g_can.txFail = 0U;
    g_can.rxOk = 0U;   g_can.rxBad = 0U; g_can.rxSeqJump = 0U;
    g_can.busOffCnt = 0U;
    s_rxHavePrev = false;
}

static void canTransmit(void)
{
    const uint32_t objBit = 1UL << (CAN_TX_OBJ - 1U);
    uint16_t data[CAN_DLC];
    uint16_t i;
    uint32_t es;
    uint16_t lec;
    uint16_t errLec = (uint16_t)CAN_STATUS_LEC_NONE;
    uint32_t waited = 0U;
    bool sawPending = false;
    bool ok;
    char *d;

    g_can.txSeq++;
    for(i = 0U; i < CAN_DLC; i++)
    {
        data[i] = (uint16_t)((g_can.txSeq + i) & 0xFFU);
        g_can.txData[i] = data[i];
    }

    // Clear the previous TX result and error status
    CAN_clearInterruptStatus(CANA_BASE, CAN_TX_OBJ);
    (void)CAN_getStatus(CANA_BASE);

    CAN_sendMessage(CANA_BASE, CAN_TX_OBJ, CAN_DLC, data);

    // Wait until the interface register has been transferred to message RAM
    while(((HWREGH(CANA_BASE + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY) != 0U) &&
          (waited < CAN_TX_WAIT_US))
    {
        DEVICE_DELAY_US(1U);
        waited += 1U;
    }

    // Wait for the single-shot transmission to finish: either the TX object
    // interrupt-pending flag is set (success) or the request is released
    // without it (failure). Bus errors seen meanwhile are recorded.
    for(;;)
    {
        es  = CAN_getStatus(CANA_BASE);
        lec = (uint16_t)(es & CAN_STATUS_LEC_MSK);
        if((lec != (uint16_t)CAN_STATUS_LEC_NONE) && (lec != 7U)) { errLec = lec; }

        if((CAN_getTxRequests(CANA_BASE) & objBit) != 0UL)
        {
            sawPending = true;
        }
        if((HWREG_BP(CANA_BASE + CAN_O_IPEN_21) & objBit) != 0UL)
        {
            break;                                  // transmitted
        }
        if((sawPending && ((CAN_getTxRequests(CANA_BASE) & objBit) == 0UL)) ||
           (waited >= CAN_TX_WAIT_US))
        {
            break;                                  // failed or timed out
        }
        DEVICE_DELAY_US(10U);
        waited += 10U;
    }

    ok = ((HWREG_BP(CANA_BASE + CAN_O_IPEN_21) & objBit) != 0UL);
    CAN_clearInterruptStatus(CANA_BASE, CAN_TX_OBJ);

    g_can.txLastLec = ok ? (uint16_t)CAN_STATUS_LEC_NONE : errLec;
    if(ok) { g_can.txOk++; } else { g_can.txFail++; }

    d = putStr(s_line, "TX ID=0x");
    d = putHex(d, CAN_TX_ID, 3U);
    d = putStr(d, " seq=");
    d = putU32(d, g_can.txSeq);
    if(ok)
    {
        d = putStr(d, " ACK OK");
    }
    else
    {
        d = putStr(d, " FAIL ");
        d = putStr(d, (waited >= CAN_TX_WAIT_US) ? "TIMEOUT" : lecName(g_can.txLastLec));
    }
    d = putStr(d, " txOK=");   d = putU32(d, g_can.txOk);
    d = putStr(d, " txFail="); d = putU32(d, g_can.txFail);
    logLine(d);
    logPayload("TX DATA:", g_can.txData);
}

static void canReceive(void)
{
    uint16_t data[CAN_DLC];
    uint16_t i;
    bool good = true;
    char *d;

    if(!CAN_readMessage(CANA_BASE, CAN_RX_OBJ, data))
    {
        return;
    }

    for(i = 0U; i < CAN_DLC; i++)
    {
        data[i] &= 0xFFU;
        g_can.rxData[i] = data[i];
        if(data[i] != ((data[0] + i) & 0xFFU)) { good = false; }
    }
    if(good) { g_can.rxOk++; } else { g_can.rxBad++; }

    if(good && s_rxHavePrev && (data[0] != ((s_rxPrevFirst + 1U) & 0xFFU)))
    {
        g_can.rxSeqJump++;
        d = putStr(s_line, "[WARN] SEQ JUMP expected ");
        d = putHex(d, (s_rxPrevFirst + 1U) & 0xFFU, 2U);
        d = putStr(d, " got ");
        d = putHex(d, data[0], 2U);
        logLine(d);
    }
    if(good)
    {
        s_rxPrevFirst = data[0];
        s_rxHavePrev  = true;
    }

    d = putStr(s_line, "RX ID=0x");
    d = putHex(d, CAN_RX_ID, 3U);
    d = putStr(d, good ? " PASS" : " FAIL");
    d = putStr(d, " rxOK=");  d = putU32(d, g_can.rxOk);
    d = putStr(d, " rxBad="); d = putU32(d, g_can.rxBad);
    logLine(d);
    logPayload("RX DATA:", g_can.rxData);
}

static void canStatus(void)
{
    uint32_t rec, tec, es;
    char *d;

    CAN_getErrorCount(CANA_BASE, &rec, &tec);
    es = CAN_getStatus(CANA_BASE);
    g_can.rec        = rec;
    g_can.tec        = tec;
    g_can.status     = es;
    g_can.errPassive = ((es & CAN_STATUS_EPASS) != 0UL) ? 1U : 0U;
    g_can.busOff     = ((es & CAN_STATUS_BUS_OFF) != 0UL) ? 1U : 0U;
    if(g_can.busOff != 0U) { g_can.busOffCnt++; }   // auto bus-on recovers

    d = putStr(s_line, "STAT txOK=");   d = putU32(d, g_can.txOk);
    d = putStr(d, " txFail=");          d = putU32(d, g_can.txFail);
    d = putStr(d, " rxOK=");            d = putU32(d, g_can.rxOk);
    d = putStr(d, " rxBad=");           d = putU32(d, g_can.rxBad);
    d = putStr(d, " seqJump=");         d = putU32(d, g_can.rxSeqJump);
    d = putStr(d, " TEC=");             d = putU32(d, tec);
    d = putStr(d, " REC=");             d = putU32(d, rec);
    d = putStr(d, (g_can.busOff != 0U) ? " BUS-OFF" :
                  ((g_can.errPassive != 0U) ? " ERR-PASSIVE" : " ERR-ACTIVE"));
    logLine(d);
}

//-----------------------------------------------------------------------------
// UART command interpreter: START / STOP / RESET
//-----------------------------------------------------------------------------
static char     s_cmdBuf[CMD_MAX_LEN];
static uint16_t s_cmdLen      = 0U;
static bool     s_cmdTooLong  = false;
static uint32_t s_cmdLastRxMs = 0U;

static bool strEq(const char *a, const char *b)
{
    while((*a != '\0') && (*a == *b)) { a++; b++; }
    return (*a == *b);
}

static void cmdExecute(void)
{
    uint16_t i;

    s_cmdBuf[s_cmdLen] = '\0';
    for(i = 0U; i <= s_cmdLen; i++) { g_cmdLast[i] = s_cmdBuf[i]; }

    if(s_cmdTooLong)
    {
        UART_puts("ERR CMD TOO LONG\r\n");
    }
    else if(strEq(s_cmdBuf, "STOP"))
    {
        UART_puts("OK STOP - log disabled (CAN keeps running)\r\n");
        g_logEnable = 0U;
    }
    else if(strEq(s_cmdBuf, "START"))
    {
        UART_puts("OK START - log enabled\r\n");
        g_logEnable = 1U;
    }
    else if(strEq(s_cmdBuf, "RESET"))
    {
        canResetCounters();
        UART_puts("OK RESET - counters cleared\r\n");
    }
    else
    {
        UART_puts("ERR UNKNOWN CMD: ");
        UART_puts(s_cmdBuf);
        UART_puts(" (use START / STOP / RESET)\r\n");
    }

    s_cmdLen     = 0U;
    s_cmdTooLong = false;
}

static void cmdPoll(void)
{
    int16_t c;

    while((c = UART_getc()) >= 0)
    {
        g_uartRxCnt++;
        s_cmdLastRxMs = g_msTick;

        if((c == '\r') || (c == '\n'))
        {
            if((s_cmdLen > 0U) || s_cmdTooLong) { cmdExecute(); }
        }
        else if((c == 0x08) || (c == 0x7F))     // backspace
        {
            if(s_cmdLen > 0U) { s_cmdLen--; }
        }
        else if((c <= 0x20) || (c > 0x7E))
        {
            // ignore spaces and control characters
        }
        else if(s_cmdLen < (CMD_MAX_LEN - 1U))
        {
            if((c >= 'a') && (c <= 'z')) { c = (int16_t)(c - 'a' + 'A'); }
            s_cmdBuf[s_cmdLen++] = (char)c;
        }
        else
        {
            s_cmdTooLong = true;
        }
    }

    // Terminals that send without CR/LF: execute after an idle gap
    if(((s_cmdLen > 0U) || s_cmdTooLong) &&
       ((g_msTick - s_cmdLastRxMs) >= CMD_IDLE_MS))
    {
        cmdExecute();
    }
}

//-----------------------------------------------------------------------------
void main(void)
{
    Device_init();
    Device_initGPIO();

    Interrupt_initModule();
    Interrupt_initVectorTable();

    boardInit();
    UART_init();
    canInit();
    canResetCounters();
    tickTimerInit();

    EINT;
    ERTM;

    UART_puts("\r\n=== F280049C <-> STM32G474 CAN 2.0 test ===\r\n"
              "CANA GPIO32 TX / GPIO33 RX, 500 kbps\r\n"
              "F28 TX ID 0x321 / RX ID 0x123, 8 bytes ramp, 1 s\r\n"
              "Commands: START / STOP / RESET\r\n");

    for(;;)
    {
        cmdPoll();
        canReceive();

        if(g_txFlag != 0U)
        {
            g_txFlag = 0U;
            canTransmit();
            canStatus();
        }
    }
}

//-----------------------------------------------------------------------------
__interrupt void cpuTimer0ISR(void)     // 1 ms
{
    static uint16_t ledCnt = 0U;
    static uint16_t txCnt  = 0U;

    g_msTick++;

    if(++txCnt >= CAN_TX_PERIOD_MS)
    {
        txCnt = 0U;
        g_txFlag = 1U;
    }

    if(++ledCnt >= 500U)
    {
        ledCnt = 0U;
        GPIO_togglePin(LED_STATUS_PIN);
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
